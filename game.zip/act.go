package game

// type Act string
type ActCommand string

type Acting struct {
	target Code
	coords Coords
}

// var actMap map[Act]Acting
var actCommandMap map[ActCommand][]Act

/* const (
	upAct        Act = "위"
	downAct      Act = "아래"
	rightAct     Act = "오른쪽"
	leftAct      Act = "왼쪽"
	openAct      Act = "열기"
	breakOpenAct Act = "부숴서열기"
	keyOpenAct   Act = "열쇠열기"
) */

/* func initActMap() {
	upCoords, downCoords, rightCoords, leftCoords := getAroundCoords(Coords{})
	up := Acting{target: codeFloor, coords: upCoords}
	down := Acting{target: codeFloor, coords: downCoords}
	right := Acting{target: codeFloor, coords: rightCoords}
	left := Acting{target: codeFloor, coords: leftCoords}

	open := Acting{target: codeWoodDoor}
	breakOpen := Acting{target: codeGlassDoor}
	keyOpen := Acting{target: codeGoalDoor}

	actMap = map[Act]Acting{
		codeUp:       up,
		codeDown:      down,
		rightAct:     right,
		leftAct:      left,
		openAct:      open,
		breakOpenAct: breakOpen,
		keyOpenAct:   keyOpen,
		// getHammer :
	}
} */

func initActCommandMap() {
	actCommandMap = map[ActCommand][]Act{
		"위": {codeUp},
		"앞": {codeUp},
		"상": {codeUp},
		"북": {codeUp},

		"아래": {codeDown},
		"밑":  {codeDown},
		"하":  {codeDown},
		"남":  {codeDown},

		"오른": {codeRight},
		"우":  {codeRight},
		"동":  {codeRight},

		"왼": {codeLeft},
		"좌": {codeLeft},
		"서": {codeLeft},

		"연":  {codeOpen, codeBreak, codeUnlock},
		"열":  {codeOpen, codeBreak, codeUnlock},
		"사용": {codeOpen, codeBreak, codeUnlock},
		"이용": {codeOpen, codeBreak, codeUnlock},

		"부수": {codeBreak},
		"부순": {codeBreak},
		"깨":  {codeBreak},
		"깬":  {codeBreak},

		// "줍": {getHammer, getKey},
	}
}

/* func (act Act) getActing() Acting {
	return actMap[act]
} */

func (act Act) getDirectionCoords() Coords {
	coords := Coords{}
	upCoords, downCoords, rightCoords, leftCoords := getAroundCoords(coords)

	switch act {
	case codeUp:
		coords = upCoords
	case codeDown:
		coords = downCoords
	case codeRight:
		coords = rightCoords
	case codeLeft:
		coords = leftCoords
	}
	return coords
}

func move(act []Act) {
	actName := act[0]
	move := actName.getActing()
	if move.target == codeFloor {
		directionCoords := newCoords(playInfo.currentCoords, move.coords)
		if checkOutFieldByCoords(directionCoords) || *getPlaceByCoords(directionCoords) == codeBlank {
			blankScript.print()
			return
		}

		directionPlace := getPlaceByCoords(directionCoords)

		if (*directionPlace).isOpenDoor() {
			if directionCoords == playInfo.goalCoords {
				endGame = true
				updatePlayerPlace(directionCoords, directionPlace)
				return
			}
			// doorName := attributeMap[Code((*directionPlace).getDoorNumber())*door].getName()
			doorName := (*directionPlace).getName()
			passDoorScript.print(doorName)

			directionCoords = newCoords(directionCoords, move.coords)
			directionPlace = getPlaceByCoords(directionCoords)

			updatePlayerPlace(directionCoords, directionPlace)
			return
		}

		if (*directionPlace).isDoor() {
			doorName := attributeMap[(*directionPlace)].getName()
			closeDoorScript.print(doorName)
			return
		}

		moveScript.print(actName)

		if (*directionPlace).isItem() {
			itemName := attributeMap[(*directionPlace)].getName()
			findItmeScript.print(itemName)
			inventory := &playInfo.inventory
			*inventory = append(*inventory, (*directionPlace))
		}

		// 현재 위치 업데이트
		updatePlayerPlace(directionCoords, directionPlace)
	}
}

func actByAttribute(door Code, item Code, acts []Act) {
	ifDoor, _ := playInfo.getAroundDoorCoords()
	ifDoorIsOpen := ifDoor != nil && (*ifDoor).isOpenDoor()
	if door > 0 && !checkActToDoor(acts, door, ifDoor, ifDoorIsOpen) {
		return
	}

	if item > 0 && !checkInventory(item) {
		notHaveItemScript.print(item.getName())
		return
	}

	if door == codeWoodDoor && item == 0 {
		item = codeHand
	}

	if door > 0 && item > 0 {
		if ifDoor != nil && ifDoorIsOpen {
			alreadyOpenDoorScript.print((*ifDoor).getName())
			return
		}

		openingDoor := door + item
		aroundDoor, _ := playInfo.getAroundDoorCoords()

		if *aroundDoor == door && openingDoor.isOpenDoor() {
			useItemToDoorScript.print(item.getName(), door.getName())
			*aroundDoor = openingDoor
		} else {
			canNotUseItemToDoorScript.print(item.getName(), door.getName())
		}
	}
}
